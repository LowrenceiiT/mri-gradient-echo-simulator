
import React from 'react';
import { SequenceParams, TissueParams, SequenceType, DifficultyLevel } from '../types';
import { TISSUES, EQUATION_TYPES, SEQUENCE_DEFAULTS } from '../constants';
import { Settings2, Activity, Clock, RotateCw, Calculator, Bot, Sliders, GraduationCap, RotateCcw, Timer } from 'lucide-react';

interface ControlPanelProps {
  seqParams: SequenceParams;
  tissueParams: TissueParams;
  onSeqChange: (params: SequenceParams) => void;
  onTissueChange: (params: TissueParams) => void;
  ernstAngle: number;
  isTeaching: boolean;
  difficulty: DifficultyLevel;
  setDifficulty: (level: DifficultyLevel) => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  seqParams,
  tissueParams,
  onSeqChange,
  onTissueChange,
  ernstAngle,
  isTeaching,
  difficulty,
  setDifficulty
}) => {
  
  const handleSeqChange = (key: keyof SequenceParams, value: any) => {
    if (isTeaching && key !== 'sequenceType') return; 
    
    // Smart Switching: If sequence type changes, load its defaults
    if (key === 'sequenceType') {
        const newType = value as SequenceType;
        const defaults = SEQUENCE_DEFAULTS[newType];
        onSeqChange({
            ...seqParams,
            sequenceType: newType,
            ...defaults // Apply physics-accurate defaults immediately
        });
    } else {
        onSeqChange({ ...seqParams, [key]: value });
    }
  };

  const handleReset = () => {
      if (isTeaching) return;
      const defaults = SEQUENCE_DEFAULTS[seqParams.sequenceType];
      onSeqChange({
          ...seqParams,
          ...defaults
      });
  };

  const handlePresetClick = (key: string) => {
    if (isTeaching) return;
    onTissueChange(TISSUES[key]);
  };

  return (
    <div className={`bg-zinc-900 border-r border-zinc-800 w-full lg:w-80 h-full flex flex-col overflow-y-auto transition-opacity duration-300 ${isTeaching ? 'pointer-events-none' : ''}`}>
      <div className="p-6 border-b border-zinc-800 relative">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <Activity className="text-cyan-400" />
          GRE Simulator
        </h1>
        
        {/* Difficulty Selector */}
        <div className="mt-4 flex items-center gap-2 pointer-events-auto">
           <GraduationCap size={14} className="text-zinc-500" />
           <select 
             value={difficulty}
             onChange={(e) => setDifficulty(e.target.value as DifficultyLevel)}
             className="bg-zinc-800 text-xs text-zinc-300 border border-zinc-700 rounded px-2 py-1 outline-none focus:border-cyan-500"
             disabled={isTeaching}
           >
             <option value="basic">Basic Mode</option>
             <option value="normal">Normal Mode</option>
             <option value="expert">Expert Mode</option>
           </select>
        </div>
        
        {isTeaching && (
          <div className="absolute top-6 right-6 flex items-center gap-1 bg-fuchsia-500/20 border border-fuchsia-500/50 text-fuchsia-300 px-2 py-1 rounded text-xs animate-pulse">
            <Bot size={12} /> AI Control
          </div>
        )}
      </div>

      {/* Sequence Type Selector */}
      <div className="p-6 border-b border-zinc-800 bg-zinc-900/50 pointer-events-auto" id="ctrl-sequence-type">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                <Calculator size={14} /> Equation Model
            </h2>
            <button 
                onClick={handleReset}
                disabled={isTeaching}
                className="p-1.5 text-zinc-500 hover:text-white hover:bg-zinc-700 rounded transition-colors"
                title="Reset Parameters to Default"
            >
                <RotateCcw size={14} />
            </button>
        </div>
        
        <div className="space-y-3">
          <select 
            value={seqParams.sequenceType}
            onChange={(e) => handleSeqChange('sequenceType', e.target.value as SequenceType)}
            className="w-full bg-zinc-800 border border-zinc-700 text-white text-sm rounded-md p-2 focus:ring-2 focus:ring-cyan-500 outline-none"
            disabled={isTeaching}
          >
            {Object.entries(EQUATION_TYPES).map(([key, info]) => (
                <option key={key} value={key}>{info.name}</option>
            ))}
          </select>
          <p className="text-[11px] text-zinc-500 leading-relaxed border-l-2 border-zinc-700 pl-2">
            {difficulty === 'basic' 
              ? EQUATION_TYPES[seqParams.sequenceType].description.split('.')[0] + "." // Simplified text
              : EQUATION_TYPES[seqParams.sequenceType].description
            }
          </p>
        </div>
      </div>

      {/* Tissue Presets */}
      <div className="p-6 border-b border-zinc-800" id="ctrl-tissues">
        <h2 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4">Tissue Presets</h2>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(TISSUES).map(([key, tissue]) => (
            <button
              key={key}
              onClick={() => handlePresetClick(key)}
              disabled={isTeaching}
              className={`px-3 py-2 text-sm rounded-md transition-all border ${
                tissueParams.name === tissue.name
                  ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200'
                  : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:bg-zinc-750'
              } ${isTeaching ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {key}
            </button>
          ))}
        </div>
        
        {/* Custom Tissue Params - Hide in Basic */}
        {difficulty !== 'basic' && (
          <div className="mt-4 space-y-4 pt-4 border-t border-zinc-800/50">
            <div id="ctrl-t1">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-400">T1 (Longitudinal)</span>
                <span className="text-cyan-400">{tissueParams.t1} ms</span>
              </div>
              <input
                type="range"
                min="100"
                max="5000"
                step="50"
                value={tissueParams.t1}
                onChange={(e) => onTissueChange({...tissueParams, t1: Number(e.target.value), name: 'Custom'})}
                disabled={isTeaching}
                className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 disabled:accent-zinc-600"
              />
            </div>
          </div>
        )}
      </div>

      {/* Sequence Parameters */}
      <div className="p-6 flex-1">
        <h2 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Settings2 size={16} /> Sequence Parameters
        </h2>
        
        <div className="space-y-6">
          {/* TR Control */}
          <div className="transition-all duration-500" id="ctrl-tr">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-zinc-300 font-medium flex items-center gap-1">
                <Clock size={12} /> Repetition Time (TR)
              </span>
              <span className={`font-mono ${isTeaching ? 'text-fuchsia-400 font-bold scale-110' : 'text-white'} transition-all`}>{seqParams.tr} ms</span>
            </div>
            <input
              type="range"
              min="10"
              max="10000" // Extended max for FLAIR/Inversion
              step="10"
              value={seqParams.tr}
              onChange={(e) => handleSeqChange('tr', Number(e.target.value))}
              disabled={isTeaching}
              className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 disabled:accent-zinc-600"
            />
          </div>

          {/* TE Control */}
          <div className="transition-all duration-500" id="ctrl-te">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-zinc-300 font-medium flex items-center gap-1">
                <Clock size={12} /> Echo Time (TE)
              </span>
              <span className={`font-mono ${isTeaching ? 'text-fuchsia-400 font-bold scale-110' : 'text-white'} transition-all`}>{seqParams.te} ms</span>
            </div>
            <input
              type="range"
              min="1"
              max="200"
              step="0.5"
              value={seqParams.te}
              onChange={(e) => handleSeqChange('te', Number(e.target.value))}
              disabled={isTeaching}
              className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 disabled:accent-zinc-600"
            />
          </div>

          {/* Inversion Time (TI) Control - Only for IR sequences */}
          {seqParams.sequenceType === 'inversion' && (
             <div className="transition-all duration-500 animate-in fade-in slide-in-from-left-4" id="ctrl-ti">
                <div className="flex justify-between text-xs mb-1">
                <span className="text-purple-300 font-medium flex items-center gap-1">
                    <Timer size={12} /> Inversion Time (TI)
                </span>
                <span className={`font-mono ${isTeaching ? 'text-fuchsia-400 font-bold scale-110' : 'text-purple-300'} transition-all`}>{seqParams.ti} ms</span>
                </div>
                <input
                type="range"
                min="50"
                max="4000"
                step="50"
                value={seqParams.ti}
                onChange={(e) => handleSeqChange('ti', Number(e.target.value))}
                disabled={isTeaching}
                className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-purple-500 disabled:accent-zinc-600"
                />
             </div>
          )}

          {/* Flip Angle Control */}
          <div className="p-3 bg-zinc-800/50 rounded-lg border border-zinc-700/50 transition-all duration-500" id="ctrl-flip">
            <div className="flex justify-between text-xs mb-2">
              <span className="text-zinc-300 font-medium flex items-center gap-1">
                <RotateCw size={12} /> Flip Angle (α)
              </span>
              <span className={`font-mono ${isTeaching ? 'text-fuchsia-400 font-bold scale-110' : 'text-white'} transition-all`}>{seqParams.flipAngle}°</span>
            </div>
            <input
              type="range"
              min="1"
              max="90"
              step="1"
              value={seqParams.flipAngle}
              onChange={(e) => handleSeqChange('flipAngle', Number(e.target.value))}
              disabled={isTeaching}
              className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-emerald-500 disabled:accent-zinc-600"
            />
            
            {seqParams.sequenceType === 'spoiled' && (
                <div className={`mt-3 pt-3 border-t border-zinc-700/50 flex justify-between items-center transition-opacity ${isTeaching ? 'opacity-30' : 'opacity-100'}`}>
                <span className="text-[10px] text-zinc-400">Ernst Angle (for T1)</span>
                <button 
                    onClick={() => handleSeqChange('flipAngle', Math.round(ernstAngle))}
                    disabled={isTeaching}
                    className="text-xs font-mono bg-emerald-500/20 text-emerald-300 px-2 py-1 rounded hover:bg-emerald-500/30 transition-colors"
                >
                    {ernstAngle.toFixed(1)}°
                </button>
                </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Gradient Controls - Expert Only */}
      {difficulty === 'expert' && (
        <div className="p-6 border-t border-zinc-800" id="ctrl-gradients">
          <h2 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Sliders size={14} /> Gradient Amplitudes
          </h2>
          <div className="space-y-4">
              {/* Gz - Slice Select */}
              <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-emerald-400 font-medium">Gz (Slice)</span>
                    <span className="text-zinc-400 font-mono">{seqParams.gzAmp.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="2.0"
                    step="0.1"
                    value={seqParams.gzAmp}
                    onChange={(e) => handleSeqChange('gzAmp', Number(e.target.value))}
                    disabled={isTeaching}
                    className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-emerald-500 disabled:accent-zinc-600"
                  />
              </div>

              {/* Gy - Phase Encode */}
              <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-blue-400 font-medium">Gy (Phase)</span>
                    <span className="text-zinc-400 font-mono">{seqParams.gyAmp.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="2.0"
                    step="0.1"
                    value={seqParams.gyAmp}
                    onChange={(e) => handleSeqChange('gyAmp', Number(e.target.value))}
                    disabled={isTeaching}
                    className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:accent-zinc-600"
                  />
              </div>

              {/* Gx - Frequency Encode */}
              <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-red-400 font-medium">Gx (Freq)</span>
                    <span className="text-zinc-400 font-mono">{seqParams.gxAmp.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="2.0"
                    step="0.1"
                    value={seqParams.gxAmp}
                    onChange={(e) => handleSeqChange('gxAmp', Number(e.target.value))}
                    disabled={isTeaching}
                    className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-red-500 disabled:accent-zinc-600"
                  />
              </div>
          </div>
        </div>
      )}
    </div>
  );
};
