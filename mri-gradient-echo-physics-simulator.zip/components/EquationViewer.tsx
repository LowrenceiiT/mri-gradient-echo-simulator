
import React from 'react';
import { SequenceParams } from '../types';

interface EquationViewerProps {
  seqParams: SequenceParams;
}

export const EquationViewer: React.FC<EquationViewerProps> = ({ seqParams }) => {
  const { sequenceType } = seqParams;

  const renderSpoiledEquation = () => (
    <div className="flex items-center gap-2">
      <span className="text-zinc-200">S</span>
      <span>=</span>
      <span className="text-zinc-500">S₀</span>
      <div className="flex flex-col items-center mx-2">
        <span className="border-b border-zinc-600 pb-1">1 - e<sup className="text-xs text-blue-400">-TR/T₁</sup></span>
        <span className="pt-1">1 - cos(<span className="text-emerald-400">α</span>)e<sup className="text-xs text-blue-400">-TR/T₁</sup></span>
      </div>
      <span>·</span>
      <span className="ml-1">sin(<span className="text-emerald-400">α</span>)</span>
      <span>·</span>
      <span>e<sup className="text-xs text-red-400">-TE/T₂*</sup></span>
    </div>
  );

  const renderBSSFPEquation = () => (
    <div className="flex items-center gap-2">
      <span className="text-zinc-200">S</span>
      <span>=</span>
      <span className="text-zinc-500">S₀</span>
      <div className="flex flex-col items-center mx-2">
        <span className="border-b border-zinc-600 pb-1">sin(<span className="text-emerald-400">α</span>) · (1 - e<sup className="text-xs text-blue-400">-TR/T₁</sup>)</span>
        <span className="pt-1">
          1 - (e<sup className="text-xs text-blue-400">-TR/T₁</sup> - e<sup className="text-xs text-purple-400">-TR/T₂</sup>)cos(<span className="text-emerald-400">α</span>) 
          - e<sup className="text-xs text-blue-400">-TR/T₁</sup>e<sup className="text-xs text-purple-400">-TR/T₂</sup>
        </span>
      </div>
      <span>·</span>
      <span>e<sup className="text-xs text-purple-400">-TE/T₂</sup></span>
    </div>
  );

  const renderFISPEquation = () => (
     <div className="flex items-center gap-2">
      <span className="text-zinc-200">S</span>
      <span>≈</span>
      <span className="text-zinc-500">S₀</span>
      <div className="flex flex-col items-center mx-2">
        <span className="border-b border-zinc-600 pb-1">sin(<span className="text-emerald-400">α</span>) · (1 - e<sup className="text-xs text-blue-400">-TR/T₁</sup>)</span>
        <span className="pt-1">
            1 - e<sup className="text-xs text-blue-400">-TR/T₁</sup>cos(<span className="text-emerald-400">α</span>) - E₂·(E₁ - cos(<span className="text-emerald-400">α</span>))
        </span>
      </div>
      <span>·</span>
      <span>e<sup className="text-xs text-red-400">-TE/T₂*</sup></span>
    </div>
  );

  const renderInversionEquation = () => (
    <div className="flex items-center gap-2">
      <span className="text-zinc-200">S</span>
      <span>=</span>
      <span className="text-zinc-500">S₀</span>
      <span className="text-xl mx-1">|</span>
      <span>1 - 2e<sup className="text-xs text-purple-400">-TI/T₁</sup> + e<sup className="text-xs text-blue-400">-TR/T₁</sup></span>
      <span className="text-xl mx-1">|</span>
      <span>·</span>
      <span className="ml-1">sin(<span className="text-emerald-400">α</span>)</span>
      <span>·</span>
      <span>e<sup className="text-xs text-red-400">-TE/T₂*</sup></span>
    </div>
  );

  return (
    <div className="w-full bg-zinc-900 border-b border-zinc-800 p-4 overflow-x-auto flex justify-center items-center min-h-[80px]">
      <div className="text-zinc-400 font-serif italic text-lg md:text-xl select-none pointer-events-none whitespace-nowrap px-4">
        {sequenceType === 'spoiled' && renderSpoiledEquation()}
        {sequenceType === 'bssfp' && renderBSSFPEquation()}
        {sequenceType === 'fisp' && renderFISPEquation()}
        {sequenceType === 'inversion' && renderInversionEquation()}
      </div>
    </div>
  );
};
