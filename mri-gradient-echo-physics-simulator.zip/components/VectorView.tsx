
import React, { useEffect, useRef, useState } from 'react';
import { SequenceParams, TissueParams } from '../types';
import { Rotate3d, Square, Home, ArrowDownToLine, Eye } from 'lucide-react';
import { calculateSignal } from '../utils/physics';

interface VectorViewProps {
  seqParams: SequenceParams;
  tissueParams: TissueParams;
  timeInTR: number; // 0 to 100 representing percentage of TR
}

export const VectorView: React.FC<VectorViewProps> = ({ seqParams, tissueParams, timeInTR }) => {
  const [is3D, setIs3D] = useState(false);
  const plotlyRef = useRef<HTMLDivElement>(null);
  
  // Calculate Analytical State for current timeInTR
  // This ensures perfect synchronization with the App clock
  
  // 1. Determine Starting Magnetization (Just after excitation pulse)
  // For standard GRE, Mz_avail = Mz_steady.
  // For Inversion Recovery, Mz_avail depends on TI.
  
  let Mz_available = 1;
  const E1 = Math.exp(-seqParams.tr / tissueParams.t1); // Simple steady state approximation
  
  if (seqParams.sequenceType === 'inversion') {
     // Mz at TI = 1 - 2*exp(-TI/T1) + exp(-TR/T1)
     const E_TI = Math.exp(-seqParams.ti / tissueParams.t1);
     Mz_available = 1 - 2 * E_TI + E1;
  } else {
     // Standard GRE Steady State Approx
     // Mz = (1-E1)/(1-cos(alpha)*E1) roughly
     const alphaRad = (seqParams.flipAngle * Math.PI) / 180;
     const cosA = Math.cos(alphaRad);
     Mz_available = (1 - E1) / (1 - cosA * E1); 
  }

  const alphaRad = (seqParams.flipAngle * Math.PI) / 180;
  
  // Mz immediately after pulse
  const mzStart = Mz_available * Math.cos(alphaRad);
  // Mxy immediately after pulse (Magnitude)
  const mxyStart = Math.abs(Mz_available * Math.sin(alphaRad));

  // 2. Apply Relaxation over time (during the readout/TR period displayed)
  // timeMs = (timeInTR / 100) * seqParams.tr
  const timeMs = (timeInTR / 100) * seqParams.tr;
  
  const recoveryFactor = Math.exp(-timeMs / tissueParams.t1);
  const decayConst = seqParams.sequenceType === 'bssfp' ? tissueParams.t2 : tissueParams.t2star;
  const decayFactor = Math.exp(-timeMs / decayConst);
  
  // Mz Recovery logic:
  // Recover towards 1 from mzStart
  const mzCurrent = 1 - (1 - mzStart) * recoveryFactor;
  const mxyCurrent = mxyStart * decayFactor;

  // 3. Phase evolution (precession)
  const phase = timeMs * 0.1; // Arbitrary speed for visual rotation

  // Handle Camera Presets
  const setCameraView = (view: 'iso' | 'top' | 'side') => {
    if (!plotlyRef.current || !window.Plotly) return;
    
    let camera = {};
    switch (view) {
      case 'top':
        camera = { eye: { x: 0, y: 0, z: 2.2 }, up: {x: 0, y: 1, z: 0} };
        break;
      case 'side':
        camera = { eye: { x: 2.2, y: 0, z: 0 }, up: {x: 0, y: 0, z: 1} };
        break;
      case 'iso':
      default:
        camera = { eye: { x: 1.5, y: 1.5, z: 1.2 }, up: {x: 0, y: 0, z: 1} };
        break;
    }

    window.Plotly.relayout(plotlyRef.current, { 'scene.camera': camera });
  };

  // Update Plotly 3D View
  useEffect(() => {
    if (!is3D || !window.Plotly || !plotlyRef.current) return;

    const mx = mxyCurrent * Math.cos(phase);
    const my = mxyCurrent * Math.sin(phase);
    
    const data = [
      {
        type: 'scatter3d',
        mode: 'lines',
        x: [0, 0],
        y: [0, 0],
        z: [0, mzCurrent],
        line: { width: 6, color: '#10b981' }, 
        name: 'Mz',
        hoverinfo: 'z'
      },
      {
        type: 'scatter3d',
        mode: 'lines',
        x: [0, mx],
        y: [0, 0],
        z: [0, 0],
        line: { width: 5, color: '#ef4444' }, 
        name: 'Mx',
        hoverinfo: 'x'
      },
      {
        type: 'scatter3d',
        mode: 'lines',
        x: [0, 0],
        y: [0, my],
        z: [0, 0],
        line: { width: 5, color: '#3b82f6' }, 
        name: 'My',
        hoverinfo: 'y'
      },
       {
        type: 'scatter3d',
        mode: 'lines',
        x: [mx, mx],
        y: [my, my],
        z: [0, mzCurrent],
        line: { width: 2, color: '#52525b', dash: 'dot' }, // Zinc-600
        showlegend: false,
        hoverinfo: 'skip'
      },
      {
        type: 'scatter3d',
        mode: 'lines+markers',
        x: [0, mx],
        y: [0, my],
        z: [0, mzCurrent],
        line: { width: 8, color: '#eab308' }, 
        marker: { size: 4, color: '#eab308' },
        name: 'NMV',
        hoverinfo: 'x+y+z'
      }
    ];

    const layout = {
      margin: { l: 0, r: 0, b: 0, t: 0 },
      paper_bgcolor: 'rgba(0,0,0,0)',
      plot_bgcolor: 'rgba(0,0,0,0)',
      uirevision: 'mri_sim_view', 
      scene: {
        camera: {
          eye: { x: 1.5, y: 1.5, z: 1.2 } 
        },
        xaxis: { 
          title: 'Mx', 
          range: [-1.1, 1.1], 
          gridcolor: '#3f3f46', 
          zerolinecolor: '#71717a',
          tickfont: { color: '#71717a' },
          titlefont: { color: '#ef4444' }
        },
        yaxis: { 
          title: 'My', 
          range: [-1.1, 1.1], 
          gridcolor: '#3f3f46', 
          zerolinecolor: '#71717a',
          tickfont: { color: '#71717a' },
          titlefont: { color: '#3b82f6' }
        },
        zaxis: { 
          title: 'Mz', 
          range: [-1.2, 1.2], // Range extended to handle inverted vectors
          gridcolor: '#3f3f46', 
          zerolinecolor: '#71717a',
          tickfont: { color: '#71717a' },
          titlefont: { color: '#10b981' }
        },
        aspectmode: 'cube'
      },
      showlegend: true,
      legend: {
        x: 0,
        y: 1,
        font: { color: '#d4d4d8' },
        bgcolor: 'rgba(0,0,0,0.5)'
      }
    };

    const config = { 
        displayModeBar: false, 
        displaylogo: false,
        responsive: true
    };

    window.Plotly.react(plotlyRef.current, data, layout, config);

  }, [is3D, mzCurrent, mxyCurrent, phase]);


  const center = 150;
  const radius = 100;
  const mzHeight = mzCurrent * radius;
  const mxyLen = mxyCurrent * radius;
  
  // ISOMETRIC PROJECTION CONSTANTS
  const isoAngle = 30 * (Math.PI / 180);
  const cosIso = Math.cos(isoAngle);
  const sinIso = Math.sin(isoAngle);

  // Project 3D (Mx, My, Mz) to 2D screen coordinates
  const project = (x: number, y: number, z: number) => {
    return {
      x: center + (x - y) * cosIso,
      y: center + (x + y) * sinIso - z
    };
  };

  // Vector components
  const mxVal = mxyCurrent * Math.cos(phase);
  const myVal = mxyCurrent * Math.sin(phase);
  
  const origin = project(0, 0, 0);
  const pMz = project(0, 0, mzHeight);
  const pMxy = project(mxVal * radius, myVal * radius, 0);
  const pNMV = project(mxVal * radius, myVal * radius, mzHeight);

  // Axes Endpoints
  const axisLen = 120;
  const pXAxis = project(axisLen, 0, 0);
  const pYAxis = project(0, axisLen, 0);
  const pZAxis = project(0, 0, axisLen);

  return (
    <div className="relative w-full h-full flex flex-col bg-zinc-900/50 rounded-xl border border-zinc-800 overflow-hidden" id="view-vector">
      
      <div className="absolute top-0 left-0 w-full p-4 z-20 flex justify-between items-start pointer-events-none">
        <div>
          <h3 className="text-sm font-semibold text-zinc-300">Net Magnetization</h3>
          <p className="text-xs text-zinc-500">Real-time Simulation</p>
        </div>
        <div className="flex gap-2 pointer-events-auto">
          <button 
            onClick={() => setIs3D(false)}
            className={`p-1.5 rounded transition-colors ${!is3D ? 'bg-zinc-700 text-white' : 'bg-zinc-800 text-zinc-400 hover:text-white'}`}
            title="2D Vector View"
          >
            <Square size={16} />
          </button>
          <button 
            onClick={() => setIs3D(true)}
            className={`p-1.5 rounded transition-colors ${is3D ? 'bg-cyan-600 text-white' : 'bg-zinc-800 text-zinc-400 hover:text-white'}`}
            title="3D Plot View"
          >
            <Rotate3d size={16} />
          </button>
        </div>
      </div>

      <div className="absolute top-14 right-4 z-10 text-right space-y-1 pointer-events-none">
        <div className={`text-xs font-mono drop-shadow-md ${mzCurrent < 0 ? 'text-red-400' : 'text-emerald-500'}`}>Mz: {(mzCurrent * 100).toFixed(1)}%</div>
        <div className="text-xs text-cyan-400 font-mono drop-shadow-md">Mxy: {(mxyCurrent * 100).toFixed(1)}%</div>
        <div className={`text-xs font-bold transition-colors duration-200 drop-shadow-md ${Math.abs(timeInTR - (seqParams.te / seqParams.tr * 100)) < 5 ? 'text-red-500' : 'text-zinc-700'}`}>
          {Math.abs(timeInTR - (seqParams.te / seqParams.tr * 100)) < 5 ? '• ACQUIRING' : '•'}
        </div>
      </div>

      {is3D && (
        <div className="absolute bottom-4 right-4 z-30 flex flex-col gap-2 bg-zinc-900/80 p-2 rounded-lg border border-zinc-800 backdrop-blur-sm">
           <button 
             onClick={() => setCameraView('iso')} 
             className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-700 rounded transition-colors"
             title="Reset View"
           >
             <Home size={18} />
           </button>
           <button 
             onClick={() => setCameraView('top')} 
             className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-700 rounded transition-colors"
             title="Top View (Mxy Plane)"
           >
             <ArrowDownToLine size={18} />
           </button>
           <button 
             onClick={() => setCameraView('side')} 
             className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-700 rounded transition-colors"
             title="Side View (Flip Angle)"
           >
             <Eye size={18} />
           </button>
        </div>
      )}

      <div className="flex-1 w-full h-full relative">
        {is3D ? (
          <div ref={plotlyRef} className="w-full h-full" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <svg width="300" height="300" viewBox="0 0 300 300" className="overflow-visible">
              <defs>
                <marker id="arrowhead-z" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                  <polygon points="0 0, 10 3.5, 0 7" fill="#10b981" />
                </marker>
                <marker id="arrowhead-xy" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                  <polygon points="0 0, 10 3.5, 0 7" fill="#22d3ee" />
                </marker>
                 <marker id="arrowhead-nmv" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                  <polygon points="0 0, 10 3.5, 0 7" fill="#eab308" />
                </marker>
              </defs>
              
              {/* Axes (Isometric) */}
              <line x1={origin.x} y1={origin.y} x2={pZAxis.x} y2={pZAxis.y} stroke="#3f3f46" strokeWidth="1" />
              <text x={pZAxis.x} y={pZAxis.y - 5} fill="#3f3f46" fontSize="10" textAnchor="middle">Z</text>
              
              <line x1={origin.x} y1={origin.y} x2={pXAxis.x} y2={pXAxis.y} stroke="#3f3f46" strokeWidth="1" />
               <text x={pXAxis.x + 5} y={pXAxis.y + 5} fill="#3f3f46" fontSize="10">X</text>

              <line x1={origin.x} y1={origin.y} x2={pYAxis.x} y2={pYAxis.y} stroke="#3f3f46" strokeWidth="1" />
               <text x={pYAxis.x - 5} y={pYAxis.y + 5} fill="#3f3f46" fontSize="10">Y</text>

              {/* Vectors */}
              <line 
                x1={origin.x} y1={origin.y} 
                x2={pMz.x} y2={pMz.y} 
                stroke="#10b981" strokeWidth="3" 
                strokeOpacity="0.5"
                strokeDasharray="4 4"
                markerEnd="url(#arrowhead-z)"
              />
              <line 
                x1={origin.x} y1={origin.y} 
                x2={pMxy.x} y2={pMxy.y} 
                stroke="#22d3ee" strokeWidth="3" 
                strokeOpacity="0.5"
                strokeDasharray="4 4"
                markerEnd="url(#arrowhead-xy)"
              />

              <line 
                x1={origin.x} y1={origin.y} 
                x2={pNMV.x} y2={pNMV.y} 
                stroke="#eab308" strokeWidth="4" 
                markerEnd="url(#arrowhead-nmv)"
              />
            </svg>
          </div>
        )}
      </div>

      <div className="absolute bottom-0 left-0 w-full h-1 bg-zinc-800">
        <div 
          className="h-full bg-emerald-500 transition-all duration-75" 
          style={{ width: `${Math.min(timeInTR, 100)}%` }}
        />
        <div 
            className="absolute top-0 h-2 w-0.5 bg-red-500 -mt-0.5"
            style={{ left: `${Math.min((seqParams.te / seqParams.tr) * 100, 100)}%` }}
        />
      </div>
    </div>
  );
};
