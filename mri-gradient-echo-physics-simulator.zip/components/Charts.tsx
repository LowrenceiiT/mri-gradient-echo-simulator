
import React, { useMemo, useState, useEffect } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceDot,
  ReferenceLine,
  Legend
} from 'recharts';
import { SequenceParams, TissueParams } from '../types';
import { calculateSignal, generateMultiCurveData } from '../utils/physics';
import { TISSUES } from '../constants';

interface ChartsProps {
  seqParams: SequenceParams;
  tissueParams: TissueParams; // The currently selected tissue
  ernstAngle: number;
  activeTab?: 'flipAngle' | 'tr' | 'te' | 'contrast' | 'relaxation' | 't2relaxation' | 'ti';
  onTabChange?: (tab: any) => void;
}

// Custom Tooltip
const CustomTooltip = ({ active, payload, label, xLabel }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-zinc-900 border border-zinc-700 p-2 rounded shadow-lg text-xs z-50">
        <p className="text-zinc-400 mb-1">{xLabel}: <span className="text-white">{label}</span></p>
        {payload.map((entry: any) => (
          <div key={entry.name} className="flex items-center gap-2 mb-0.5">
             <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }}></div>
             <span style={{ color: entry.color }}>{entry.name}:</span>
             <span className="font-mono text-zinc-200">{entry.value.toFixed(3)}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

// Pulsing Dot for current selection
const PulsingDot = (props: any) => {
  const { cx, cy, stroke, r, fill } = props;
  if (!Number.isFinite(cx) || !Number.isFinite(cy)) return null;
  return (
    <g>
      <circle cx={cx} cy={cy} r={r} fill={stroke} opacity="0">
        <animate attributeName="r" from={r} to={r * 3} dur="1.5s" begin="0s" repeatCount="indefinite" />
        <animate attributeName="opacity" from="0.4" to="0" dur="1.5s" begin="0s" repeatCount="indefinite" />
      </circle>
      <circle cx={cx} cy={cy} r={r} stroke={stroke} strokeWidth={2} fill={fill} />
    </g>
  );
};

export const Charts: React.FC<ChartsProps> = React.memo(({
  seqParams,
  tissueParams,
  ernstAngle,
  activeTab: controlledTab,
  onTabChange
}) => {
  const [internalTab, setInternalTab] = useState<'flipAngle' | 'tr' | 'te' | 'contrast' | 'relaxation' | 't2relaxation' | 'ti'>('flipAngle');
  
  const activeTab = controlledTab || internalTab;
  const handleTabChange = (tab: any) => {
    setInternalTab(tab);
    if (onTabChange) onTabChange(tab);
  };

  const data = useMemo(() => 
    generateMultiCurveData(activeTab, seqParams, TISSUES), 
  [activeTab, seqParams]);

  // Determine X-axis data key and label based on tab
  const getAxisConfig = () => {
    switch(activeTab) {
      case 'flipAngle': return { key: 'x', label: 'Flip Angle (°)', domain: [0, 90] };
      case 'tr': return { key: 'x', label: 'TR (ms)', domain: ['auto', 'auto'], scale: 'linear' };
      case 'te': return { key: 'x', label: 'TE (ms)', domain: [0, 200] };
      case 'ti': return { key: 'x', label: 'TI (ms)', domain: [0, 4000] }; // Range for Inversion
      case 'contrast': return { key: 'x', label: 'Flip Angle (°)', domain: [0, 90] };
      case 'relaxation': return { key: 'x', label: 'Time (ms)', domain: [0, 4000] };
      case 't2relaxation': return { key: 'x', label: 'Time (ms)', domain: [0, 500] };
      default: return { key: 'x', label: '', domain: [0, 100] };
    }
  };

  const axisConfig = getAxisConfig();
  
  // Calculate current point for ReferenceDot
  let currentX = 0;
  let currentY = 0;

  if (activeTab === 'flipAngle' || activeTab === 'contrast') {
    currentX = seqParams.flipAngle;
    if (activeTab === 'contrast') {
      currentY = Math.abs(
        calculateSignal(seqParams.tr, seqParams.te, seqParams.flipAngle, TISSUES.GM, seqParams.sequenceType, seqParams.ti) - 
        calculateSignal(seqParams.tr, seqParams.te, seqParams.flipAngle, TISSUES.WM, seqParams.sequenceType, seqParams.ti)
      );
    } else {
      currentY = calculateSignal(seqParams.tr, seqParams.te, seqParams.flipAngle, tissueParams, seqParams.sequenceType, seqParams.ti);
    }
  } else if (activeTab === 'tr') {
    currentX = seqParams.tr;
    currentY = calculateSignal(seqParams.tr, seqParams.te, seqParams.flipAngle, tissueParams, seqParams.sequenceType, seqParams.ti);
  } else if (activeTab === 'te') {
    currentX = seqParams.te;
    currentY = calculateSignal(seqParams.tr, seqParams.te, seqParams.flipAngle, tissueParams, seqParams.sequenceType, seqParams.ti);
  } else if (activeTab === 'ti') {
    currentX = seqParams.ti;
    currentY = calculateSignal(seqParams.tr, seqParams.te, seqParams.flipAngle, tissueParams, seqParams.sequenceType, seqParams.ti);
  } else if (activeTab === 'relaxation') {
    currentX = seqParams.tr;
    currentY = 1 - Math.exp(-seqParams.tr / tissueParams.t1);
  } else if (activeTab === 't2relaxation') {
    currentX = seqParams.te;
    const decayConst = seqParams.sequenceType === 'bssfp' ? tissueParams.t2 : tissueParams.t2star;
    currentY = Math.exp(-seqParams.te / decayConst);
  }

  return (
    <div className="w-full h-full bg-zinc-900/50 rounded-xl border border-zinc-800 flex flex-col overflow-hidden" id="view-charts">
      
      {/* Tabs */}
      <div className="flex border-b border-zinc-800 overflow-x-auto no-scrollbar">
        {[
          { id: 'flipAngle', label: 'Signal vs α' },
          { id: 'tr', label: 'Signal vs TR' },
          { id: 'te', label: 'Signal vs TE' },
          ...(seqParams.sequenceType === 'inversion' ? [{ id: 'ti', label: 'Signal vs TI' }] : []),
          { id: 'contrast', label: 'Contrast' },
          { id: 'relaxation', label: 'T1 Relax' },
          { id: 't2relaxation', label: 'T2 Relax' },
        ].map((tab) => (
          <button
            key={tab.id}
            id={`tab-${tab.id}`}
            onClick={() => handleTabChange(tab.id as any)}
            className={`px-3 py-3 text-xs font-medium whitespace-nowrap transition-colors border-b-2 ${
              activeTab === tab.id 
                ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5' 
                : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="flex-1 p-2 min-h-0 relative">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" opacity={0.3} />
            <XAxis 
              dataKey="x" 
              type="number"
              domain={axisConfig.domain as any}
              stroke="#71717a" 
              tick={{ fontSize: 10 }}
              label={{ value: axisConfig.label, position: 'insideBottom', offset: -5, fill: '#71717a', fontSize: 10 }}
            />
            <YAxis 
              stroke="#71717a" 
              tick={{ fontSize: 10 }} 
              label={{ 
                value: activeTab === 'contrast' ? 'Signal Difference' : (activeTab === 'relaxation' ? 'Mz Recovery' : (activeTab === 't2relaxation' ? 'Mxy Decay' : 'Signal Intensity')), 
                angle: -90, 
                position: 'insideLeft', 
                fill: '#71717a', 
                fontSize: 10,
                offset: 10
              }}
            />
            <Tooltip content={<CustomTooltip xLabel={axisConfig.label} />} />
            <Legend verticalAlign="top" align="right" wrapperStyle={{ fontSize: '10px', paddingTop: '0px' }} iconSize={8} />
            
            {/* Render lines for Tissues */}
            {activeTab !== 'contrast' && Object.values(TISSUES).map((tissue) => (
              <Line 
                key={tissue.id}
                type="monotone" 
                dataKey={tissue.id} 
                name={tissue.id}
                stroke={tissue.color} 
                strokeWidth={tissueParams.id === tissue.id ? 3 : 1.5} 
                opacity={tissueParams.id === tissue.id ? 1 : 0.4}
                dot={false}
                activeDot={{ r: 4 }}
              />
            ))}

            {/* Special Case: Contrast Chart */}
            {activeTab === 'contrast' && (
              <Line 
                type="monotone" 
                dataKey="Contrast" 
                name="GM-WM Contrast"
                stroke="#a855f7" 
                strokeWidth={3} 
                dot={false}
              />
            )}

            {/* Current Operating Point Indicator */}
            {['flipAngle', 'tr', 'te', 'relaxation', 't2relaxation', 'contrast', 'ti'].includes(activeTab) && (
              <ReferenceDot 
                x={currentX} 
                y={currentY} 
                r={4} 
                fill="#fff" 
                stroke="#eab308" 
                shape={<PulsingDot />}
              />
            )}
            
            {/* Reference Line for Ernst Angle on Flip Angle Chart */}
            {activeTab === 'flipAngle' && (
               <ReferenceLine x={ernstAngle} stroke="#10b981" strokeDasharray="3 3" label={{ value: 'Ernst', fill: '#10b981', fontSize: 10, position: 'insideTopRight' }} />
            )}
             {/* Reference Line for TR on Relaxation Chart */}
             {activeTab === 'relaxation' && (
               <ReferenceLine x={seqParams.tr} stroke="#eab308" strokeDasharray="3 3" label={{ value: 'TR', fill: '#eab308', fontSize: 10, position: 'insideTopRight' }} />
            )}
            {/* Reference Line for TE on T2* Relaxation Chart */}
            {activeTab === 't2relaxation' && (
               <ReferenceLine x={seqParams.te} stroke="#ef4444" strokeDasharray="3 3" label={{ value: 'TE', fill: '#ef4444', fontSize: 10, position: 'insideTopRight' }} />
            )}

          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
});
