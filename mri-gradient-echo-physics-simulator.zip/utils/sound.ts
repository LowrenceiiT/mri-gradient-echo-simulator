
import { SoundMode, SoundTheme } from '../types';

/**
 * MRI Audio Synthesis Engine
 * Simulates realistic gradient coil sounds using subtractive and FM synthesis.
 * Supports Visual Synchronization, Real-time Physics looping, and "All Signals" (High Fidelity).
 */
export class SoundEngine {
  ctx: AudioContext | null = null;
  masterGain: GainNode | null = null;
  humOsc: OscillatorNode | null = null;
  humGain: GainNode | null = null;

  isRunning: boolean = false;
  isMuted: boolean = true;
  
  // Settings
  mode: SoundMode = 'visual';
  theme: SoundTheme = 'mechanical';
  
  // Real-time scheduler state
  nextNoteTime: number = 0;
  timerID: number | undefined;
  
  // Params
  tr: number = 100;
  te: number = 10;
  
  // Amplitudes (0.0 - 2.0)
  gzAmp: number = 1.0;
  gyAmp: number = 1.0;
  gxAmp: number = 1.0;
  
  constructor() {
    // Lazy init
  }

  init() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
        this.masterGain = this.ctx.createGain();
        this.masterGain.connect(this.ctx.destination);
      }
    }
  }

  start() {
    this.init();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();
    
    this.isRunning = true;
    
    this.updateBackgroundHum();

    // If in Real-time or All mode, start the scheduler loop
    if (this.mode === 'realtime' || this.mode === 'all') {
      this.nextNoteTime = this.ctx.currentTime + 0.1;
      this.scheduler();
    }
  }

  stop() {
    this.isRunning = false;
    if (this.timerID) {
      window.clearTimeout(this.timerID);
      this.timerID = undefined;
    }
    this.stopBackgroundHum();
  }

  setMute(mute: boolean) {
    this.isMuted = mute;
    if (mute) {
      if (this.masterGain) this.masterGain.gain.setTargetAtTime(0, this.ctx?.currentTime || 0, 0.1);
    } else {
      if (this.masterGain) this.masterGain.gain.setTargetAtTime(1, this.ctx?.currentTime || 0, 0.1);
      if (this.isRunning && this.ctx?.state === 'suspended') {
        this.ctx.resume();
      }
    }
    this.updateBackgroundHum();
  }

  setMode(mode: SoundMode) {
    const prevMode = this.mode;
    this.mode = mode;
    
    this.updateBackgroundHum();

    if (mode === 'visual') {
      // Stop internal scheduler, rely on external triggers
      if (this.timerID) window.clearTimeout(this.timerID);
    } else {
      // Start scheduler if switching from visual
      if (this.isRunning && prevMode === 'visual') {
        this.nextNoteTime = (this.ctx?.currentTime || 0) + 0.1;
        this.scheduler();
      }
    }
  }

  setTheme(theme: SoundTheme) {
    this.theme = theme;
  }

  setParams(tr: number, te: number) {
    this.tr = tr;
    this.te = te;
  }

  setAmplitudes(gz: number, gy: number, gx: number) {
    this.gzAmp = gz;
    this.gyAmp = gy;
    this.gxAmp = gx;
  }

  // --------------------------------------------------------------------------
  // BACKGROUND HUM (Magnet & Pump Sound for 'All' Mode)
  // --------------------------------------------------------------------------
  updateBackgroundHum() {
    if (!this.ctx || !this.masterGain) return;

    const shouldPlayHum = this.isRunning && !this.isMuted && this.mode === 'all';

    if (shouldPlayHum) {
      if (!this.humOsc) {
        this.humOsc = this.ctx.createOscillator();
        this.humGain = this.ctx.createGain();
        
        // Low B0 Drone
        this.humOsc.type = 'sawtooth';
        this.humOsc.frequency.value = 50; // 50Hz mains hum / pump sound
        
        // Lowpass filter to make it a dull drone
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 120;

        this.humOsc.connect(filter);
        filter.connect(this.humGain);
        this.humGain.connect(this.masterGain);
        
        this.humOsc.start();
        this.humGain.gain.setValueAtTime(0, this.ctx.currentTime);
        this.humGain.gain.linearRampToValueAtTime(0.05, this.ctx.currentTime + 1); // Fade in
      }
    } else {
      this.stopBackgroundHum();
    }
  }

  stopBackgroundHum() {
    if (this.humGain && this.ctx) {
      this.humGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.2);
      setTimeout(() => {
        if (this.humOsc) {
            this.humOsc.stop();
            this.humOsc.disconnect();
            this.humOsc = null;
        }
        if (this.humGain) {
            this.humGain.disconnect();
            this.humGain = null;
        }
      }, 300);
    }
  }

  // --------------------------------------------------------------------------
  // EVENT TRIGGERS (Called by UI components in Visual Mode)
  // --------------------------------------------------------------------------

  triggerRF() {
    if (this.mode === 'visual' && !this.isMuted && this.ctx) this.playRFSound(this.ctx.currentTime);
  }

  triggerGradient(type: 'phase' | 'slice', amp: number) {
    if (this.mode === 'visual' && !this.isMuted && this.ctx) this.playGradientSound(this.ctx.currentTime, type, amp);
  }

  triggerReadout(amp: number) {
    if (this.mode === 'visual' && !this.isMuted && this.ctx) this.playReadoutSound(this.ctx.currentTime, amp);
  }

  // --------------------------------------------------------------------------
  // REAL-TIME SCHEDULER (Physics & All Mode)
  // --------------------------------------------------------------------------
  
  scheduler() {
    if (!this.isRunning || !this.ctx || (this.mode !== 'realtime' && this.mode !== 'all')) return;

    const lookahead = 0.1;
    
    while (this.ctx && this.nextNoteTime < this.ctx.currentTime + lookahead) {
      if (!this.isMuted) {
        // Schedule Sequence Events
        // 1. RF / Slice Select at t=0
        this.playRFSound(this.nextNoteTime);
        this.playGradientSound(this.nextNoteTime, 'slice', this.gzAmp);

        // 2. Readout at TE (if TE < TR)
        if (this.te < this.tr - 2) {
            this.playReadoutSound(this.nextNoteTime + (this.te / 1000), this.gxAmp);
        }
        
        // 3. Phase Encode (Simulated slightly after RF)
        this.playGradientSound(this.nextNoteTime + 0.01, 'phase', this.gyAmp);
      }
      
      const interval = Math.max(this.tr, 10) / 1000;
      this.nextNoteTime += interval;
    }
    
    this.timerID = window.setTimeout(() => this.scheduler(), 25);
  }

  // --------------------------------------------------------------------------
  // SOUND SYNTHESIS
  // --------------------------------------------------------------------------

  playRFSound(time: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    if (this.theme === 'mechanical') {
        // "Thump"
        osc.type = 'square';
        osc.frequency.setValueAtTime(150, time);
        osc.frequency.exponentialRampToValueAtTime(50, time + 0.05);
        gain.gain.setValueAtTime(0.3, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);
    } else {
        // "Digital Ping"
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, time);
        gain.gain.setValueAtTime(0.1, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);
    }

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(time);
    osc.stop(time + 0.1);
  }

  playGradientSound(time: number, type: 'phase' | 'slice', amp: number) {
    if (!this.ctx || !this.masterGain || amp < 0.05) return; 
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sawtooth'; 
    filter.type = 'lowpass';
    filter.Q.value = 5;

    // Scale Volume by Amplitude
    const volumeScale = Math.min(amp, 1.5); 

    // Harmonic Frequency Selection for "All Signals" richness
    let baseFreq = 120;
    if (this.theme === 'mechanical') {
        // Gz (Slice) = Low Root (100Hz)
        // Gy (Phase) = Third (125Hz)
        baseFreq = type === 'slice' ? 100 : 125; 
        
        osc.frequency.setValueAtTime(baseFreq, time);
        filter.frequency.setValueAtTime(800, time);
        
        gain.gain.setValueAtTime(0, time);
        gain.gain.linearRampToValueAtTime(0.4 * volumeScale, time + 0.005);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.03);
    } else {
        // Digital
        baseFreq = type === 'slice' ? 200 : 250;
        osc.type = 'square';
        osc.frequency.setValueAtTime(baseFreq, time);
        filter.frequency.setValueAtTime(400, time);

        gain.gain.setValueAtTime(0, time);
        gain.gain.linearRampToValueAtTime(0.15 * volumeScale, time + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);
    }

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    osc.start(time);
    osc.stop(time + 0.1);
  }

  playReadoutSound(time: number, amp: number) {
    if (!this.ctx || !this.masterGain || amp < 0.05) return;
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    const volumeScale = Math.min(amp, 1.5);

    if (this.theme === 'mechanical') {
        // "Chirp" / Whine - Fifth (150Hz) or Octave (200Hz) relative to gradients
        // Readout gradients are typically higher pitched due to switching speed
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(600, time);
        osc.frequency.linearRampToValueAtTime(900, time + 0.05); 
        
        gain.gain.setValueAtTime(0, time);
        gain.gain.linearRampToValueAtTime(0.2 * volumeScale, time + 0.01);
        gain.gain.linearRampToValueAtTime(0.2 * volumeScale, time + 0.04);
        gain.gain.linearRampToValueAtTime(0, time + 0.05);
    } else {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, time);
        
        gain.gain.setValueAtTime(0, time);
        gain.gain.linearRampToValueAtTime(0.1 * volumeScale, time + 0.01);
        gain.gain.linearRampToValueAtTime(0.1 * volumeScale, time + 0.04);
        gain.gain.linearRampToValueAtTime(0, time + 0.05);
    }

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(time);
    osc.stop(time + 0.1);
  }
}

export const soundEngine = new SoundEngine();
