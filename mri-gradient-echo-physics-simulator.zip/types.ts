
export interface TissueParams {
  id: string;
  name: string;
  t1: number; // ms
  t2: number; // ms (True T2)
  t2star: number; // ms (Effective T2)
  pd: number; // Proton Density (relative 0-1)
  color: string; // Hex color for plotting
}

export type SequenceType = 'spoiled' | 'bssfp' | 'fisp' | 'inversion';
export type DifficultyLevel = 'basic' | 'normal' | 'expert';

export interface SequenceParams {
  tr: number; // Repetition Time (ms)
  te: number; // Echo Time (ms)
  ti: number; // Inversion Time (ms) - New parameter
  flipAngle: number; // Degrees
  sequenceType: SequenceType;
  // Gradient Amplitudes (Scale factor 0.1 - 2.0)
  gzAmp: number; 
  gyAmp: number;
  gxAmp: number;
}

export interface SimulationState extends SequenceParams {
  tissue: TissueParams;
}

export interface SignalPoint {
  x: number;
  signal: number;
  isOptimal?: boolean;
}

// Teaching Mode Types
export interface TeachingStep {
  text: string;
  params?: Partial<SequenceParams>; // The engine will interpolate to these params
  delay?: number; // Time to wait after speech finishes
  highlight?: string; // ID of UI element to point at with the ghost cursor
  view?: 'vector' | 'kspace';
  chartTab?: 'flipAngle' | 'tr' | 'te' | 'contrast' | 'relaxation' | 't2relaxation' | 'ti';
}

export interface Lesson {
  title: string;
  steps: TeachingStep[];
}

export type SoundMode = 'visual' | 'realtime' | 'all';
export type SoundTheme = 'mechanical' | 'modern';

declare global {
  interface Window {
    Plotly: any;
  }
}
