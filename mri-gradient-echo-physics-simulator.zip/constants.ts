
import { TissueParams, SequenceType, SequenceParams } from './types';

// Approximate values at 1.5T field strength
export const TISSUES: Record<string, TissueParams> = {
  WM: {
    id: 'WM',
    name: 'White Matter',
    t1: 600,
    t2: 80,
    t2star: 45, 
    pd: 0.75,
    color: '#fbbf24' // Amber 400
  },
  GM: {
    id: 'GM',
    name: 'Grey Matter',
    t1: 950,
    t2: 100,
    t2star: 50,
    pd: 0.85,
    color: '#34d399' // Emerald 400
  },
  CSF: {
    id: 'CSF',
    name: 'Cerebrospinal Fluid',
    t1: 4500,
    t2: 2200,
    t2star: 200, 
    pd: 1.0,
    color: '#38bdf8' // Sky 400
  },
  FAT: {
    id: 'FAT',
    name: 'Fat',
    t1: 250,
    t2: 60,
    t2star: 30,
    pd: 0.9,
    color: '#f472b6' // Pink 400
  }
};

export const EQUATION_TYPES: Record<SequenceType, { name: string; description: string }> = {
  spoiled: {
    name: "Spoiled GRE (FLASH/SPGR)",
    description: "Transverse magnetization is destroyed (spoiled) after each TR. Pure T1/PD contrast."
  },
  bssfp: {
    name: "Balanced SSFP (TrueFISP)",
    description: "Fully balanced gradients maintain transverse magnetization. High SNR, T2/T1 contrast."
  },
  fisp: {
    name: "FISP (Steady-State GRE)",
    description: "Unspoiled gradient echo. Reuses transverse magnetization but is not fully balanced."
  },
  inversion: {
    name: "Inversion Recovery (IR-GRE)",
    description: "Prepares magnetization with a 180° inversion pulse. Used for FLAIR (CSF nulling) and STIR (Fat nulling)."
  }
};

// Scientifically accurate defaults for each sequence type
// This ensures the simulation behaves correctly immediately upon switching
export const SEQUENCE_DEFAULTS: Record<SequenceType, Omit<SequenceParams, 'sequenceType'>> = {
  spoiled: {
    tr: 150,       // Short TR for T1 weighting
    te: 5,         // Minimized TE
    ti: 0,         // N/A
    flipAngle: 60, // Ernst angle range for T1
    gzAmp: 1.2,    // Stronger spoiler needed
    gyAmp: 1.0,
    gxAmp: 1.0
  },
  bssfp: {
    tr: 10,        // Very short TR required to prevent banding
    te: 5,         // TE = TR/2 for balanced SSFP
    ti: 0,         // N/A
    flipAngle: 50, // Higher flip angle (40-60 deg) optimal for SSFP
    gzAmp: 1.5,    // High gradients for speed
    gyAmp: 1.5,
    gxAmp: 1.5
  },
  fisp: {
    tr: 50,        // Intermediate TR
    te: 10,
    ti: 0,         // N/A
    flipAngle: 30,
    gzAmp: 1.0,
    gyAmp: 1.0,
    gxAmp: 1.0
  },
  inversion: {
    tr: 6000,      // Very Long TR to allow full recovery
    te: 20,
    ti: 2000,      // Default TI (approx FLAIR range)
    flipAngle: 90, // Typically 90 degree readout
    gzAmp: 1.0,
    gyAmp: 1.0,
    gxAmp: 1.0
  }
};

export const INITIAL_PARAMS: SequenceParams = {
  sequenceType: 'spoiled',
  ...SEQUENCE_DEFAULTS['spoiled']
};
