
import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { ControlPanel } from './components/ControlPanel';
import { VectorView } from './components/VectorView';
import { KSpaceView } from './components/KSpaceView';
import { Charts } from './components/Charts';
import { EquationViewer } from './components/EquationViewer';
import { TISSUES, INITIAL_PARAMS } from './constants';
import { calculateErnstAngle, calculateSignal } from './utils/physics';
import { TissueParams, SequenceParams, SoundMode, SoundTheme, DifficultyLevel } from './types';
import { soundEngine } from './utils/sound';
import { teachingEngine } from './utils/teaching';
import { Volume2, VolumeX, Bot, X, Grid, Activity, Settings, MousePointer2 } from 'lucide-react';

// Ghost Cursor Component for Teaching Mode
const GhostCursor: React.FC<{ targetId?: string }> = ({ targetId }) => {
  const [position, setPosition] = useState({ x: -100, y: -100 });
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!targetId) {
      setVisible(false);
      return;
    }

    const updatePos = () => {
      const el = document.getElementById(targetId);
      if (el) {
        const rect = el.getBoundingClientRect();
        // Point to the center-right of the element
        setPosition({ 
          x: rect.left + rect.width / 2, 
          y: rect.top + rect.height / 2 
        });
        setVisible(true);
      }
    };

    updatePos();
    // Update on resize just in case
    window.addEventListener('resize', updatePos);
    const interval = setInterval(updatePos, 500); // Poll in case of layout shifts

    return () => {
      window.removeEventListener('resize', updatePos);
      clearInterval(interval);
    };
  }, [targetId]);

  return (
    <div 
      className="fixed pointer-events-none z-[100] transition-all duration-700 ease-in-out flex items-center gap-2"
      style={{ 
        left: position.x, 
        top: position.y, 
        opacity: visible ? 1 : 0,
        transform: `translate(0px, 0px)`
      }}
    >
      <MousePointer2 className="text-red-500 fill-red-500 drop-shadow-lg" size={32} strokeWidth={2} />
      <div className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider shadow-lg animate-pulse">
        Adjusting
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [seqParams, setSeqParams] = useState<SequenceParams>(INITIAL_PARAMS);
  const [tissueParams, setTissueParams] = useState<TissueParams>(TISSUES.GM);
  const [isMuted, setIsMuted] = useState(true);
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('normal');
  
  // Sound Settings
  const [soundMode, setSoundMode] = useState<SoundMode>('visual');
  const [soundTheme, setSoundTheme] = useState<SoundTheme>('mechanical');
  const [showSoundSettings, setShowSoundSettings] = useState(false);

  // View State
  const [activeView, setActiveView] = useState<'vector' | 'kspace'>('vector');
  
  // Teaching Mode State
  const [isTeaching, setIsTeaching] = useState(false);
  const [teachingText, setTeachingText] = useState<string>('');
  const [cursorTarget, setCursorTarget] = useState<string | undefined>(undefined);

  // Animation State (Centralized)
  const [timeInTR, setTimeInTR] = useState(0);
  const [kSpaceLine, setKSpaceLine] = useState(0);
  const [isAcquiring, setIsAcquiring] = useState(true); // New state for Play/Pause
  
  const requestRef = useRef<number | undefined>(undefined);
  const previousTimeRef = useRef<number | undefined>(undefined);
  const TOTAL_LINES = 32;

  // Constants for Triggers
  const T_RF_START = 5;
  const T_PHASE_START = 20;
  const T_READ_START = 40;

  // Update sound engine params
  useEffect(() => {
    soundEngine.setParams(seqParams.tr, seqParams.te);
    soundEngine.setAmplitudes(seqParams.gzAmp, seqParams.gyAmp, seqParams.gxAmp);
  }, [seqParams.tr, seqParams.te, seqParams.gzAmp, seqParams.gyAmp, seqParams.gxAmp]);

  // Handle Sound Settings Changes
  useEffect(() => {
    soundEngine.setMode(soundMode);
    soundEngine.setTheme(soundTheme);
  }, [soundMode, soundTheme]);

  // Clean up
  useEffect(() => {
    return () => {
      teachingEngine.stop();
      soundEngine.stop();
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  // -------------------------------------------------------------------------
  // MASTER SIMULATION LOOP
  // -------------------------------------------------------------------------
  const prevTimeInTRRef = useRef(0);
  
  const animate = useCallback((time: number) => {
    if (previousTimeRef.current !== undefined) {
      const deltaTime = time - previousTimeRef.current;
      // Simulation Speed: independent of real-time to allow visualization
      const progressSpeed = 0.05 * (100 / Math.max(seqParams.tr, 20)); 

      setTimeInTR((prev) => {
        let newTime = prev + deltaTime * progressSpeed;
        
        // ----------------------------------------
        // AUDIO TRIGGERS (Visual Sync)
        // ----------------------------------------
        const oldT = prevTimeInTRRef.current;
        
        // Check for boundary crossings
        // Note: We use thresholds defined as percentages of TR (0-100)
        
        // RF & Slice Select Trigger
        if (oldT < T_RF_START && newTime >= T_RF_START) {
            soundEngine.triggerRF();
            soundEngine.triggerGradient('slice', seqParams.gzAmp);
        }
        
        // Phase Encode Trigger - Variable Pitch based on current Line Amplitude!
        if (oldT < T_PHASE_START && newTime >= T_PHASE_START) {
            // Calculate normalized strength for current line (-1 to 1)
            const lineFraction = (kSpaceLine - TOTAL_LINES/2) / (TOTAL_LINES/2);
            // Scale by Gy Amplitude
            const currentLineAmp = Math.abs(lineFraction * seqParams.gyAmp);
            soundEngine.triggerGradient('phase', Math.max(0.1, currentLineAmp));
        }
        
        // Readout Trigger
        if (oldT < T_READ_START && newTime >= T_READ_START) {
            soundEngine.triggerReadout(seqParams.gxAmp);
        }

        // Loop TR
        if (newTime >= 100) {
          newTime = 0;
          if (isAcquiring) {
             setKSpaceLine(current => (current + 1) % TOTAL_LINES);
          }
        }
        
        prevTimeInTRRef.current = newTime;
        return newTime;
      });
    }
    previousTimeRef.current = time;
    requestRef.current = requestAnimationFrame(animate);
  }, [seqParams.tr, seqParams.gzAmp, seqParams.gyAmp, seqParams.gxAmp, isAcquiring, kSpaceLine]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current !== undefined) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [animate]);
  // -------------------------------------------------------------------------

  const toggleMute = () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    soundEngine.setMute(newMuted);
    
    if (!newMuted) {
      soundEngine.start();
    }
  };

  const toggleTeachingMode = () => {
    if (isTeaching) {
      teachingEngine.stop();
      setIsTeaching(false);
      setTeachingText('');
      setCursorTarget(undefined);
    } else {
      setIsTeaching(true);
      if (!isMuted) soundEngine.start();
      
      teachingEngine.start(
        seqParams.sequenceType,
        difficulty,
        (text, params, highlightId) => {
          setTeachingText(text);
          setCursorTarget(highlightId);
          if (params) {
            setSeqParams(prev => ({ ...prev, ...params }));
          }
        },
        () => {
          setIsTeaching(false);
          setTeachingText('Lesson Complete.');
          setCursorTarget(undefined);
          setTimeout(() => setTeachingText(''), 3000);
        }
      );
    }
  };

  const ernstAngle = useMemo(() => 
    calculateErnstAngle(seqParams.tr, tissueParams.t1), 
  [seqParams.tr, tissueParams.t1]);

  const signal = calculateSignal(seqParams.tr, seqParams.te, seqParams.flipAngle, tissueParams, seqParams.sequenceType);

  return (
    <div className="flex flex-col md:flex-row h-screen w-screen bg-zinc-950 text-zinc-100 overflow-hidden relative">
      
      {/* Ghost Cursor Overlay */}
      <GhostCursor targetId={cursorTarget} />

      {/* Overlay Captions for Teaching Mode */}
      {isTeaching && teachingText && (
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-[60] w-[90%] max-w-2xl">
          <div className="bg-zinc-900/90 border-l-4 border-fuchsia-500 text-zinc-100 p-6 rounded-r-lg shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="flex items-start gap-4">
              <div className="bg-fuchsia-500/20 p-2 rounded-full mt-1">
                <Bot size={24} className="text-fuchsia-400" />
              </div>
              <div className="flex-1">
                <h4 className="text-fuchsia-400 text-xs font-bold uppercase tracking-wider mb-1">AI Instructor ({difficulty} mode)</h4>
                <p className="text-lg font-medium leading-relaxed">{teachingText}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Left Sidebar Controls */}
      <ControlPanel 
        seqParams={seqParams}
        tissueParams={tissueParams}
        onSeqChange={setSeqParams}
        onTissueChange={setTissueParams}
        ernstAngle={ernstAngle}
        isTeaching={isTeaching}
        difficulty={difficulty}
        setDifficulty={setDifficulty}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        
        {/* Top Right Floating Actions */}
        <div className="absolute top-4 right-4 z-50 flex flex-col gap-3 items-end">
           {/* Teaching Toggle */}
           <button 
             onClick={toggleTeachingMode}
             className={`p-3 rounded-full shadow-lg transition-all flex items-center justify-center gap-2 font-bold ${
               isTeaching 
                ? 'bg-fuchsia-500 text-white hover:bg-fuchsia-600 w-12 hover:w-auto overflow-hidden group' 
                : 'bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 w-12'
             }`}
             title={isTeaching ? "Stop Class" : "Start AI Teaching Mode"}
           >
             {isTeaching ? <X size={20} /> : <Bot size={20} />}
             {isTeaching && <span className="whitespace-nowrap w-0 overflow-hidden group-hover:w-auto group-hover:pl-2 transition-all">Stop Class</span>}
           </button>

           {/* Audio Toggle & Settings */}
           <div className="flex items-center gap-2">
             {showSoundSettings && (
               <div className="bg-zinc-900 border border-zinc-700 rounded-lg p-3 shadow-xl flex flex-col gap-2 text-xs animate-in fade-in slide-in-from-right-2">
                 <div className="flex items-center justify-between gap-4">
                    <span className="text-zinc-400">Sync:</span>
                    <div className="flex bg-zinc-800 rounded p-0.5">
                       <button 
                         onClick={() => setSoundMode('visual')}
                         className={`px-2 py-1 rounded ${soundMode === 'visual' ? 'bg-cyan-600 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                         title="Synced to visual animation (slow)"
                       >Visual</button>
                       <button 
                         onClick={() => setSoundMode('realtime')}
                         className={`px-2 py-1 rounded ${soundMode === 'realtime' ? 'bg-cyan-600 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                         title="Synced to physics parameters (fast)"
                       >Physics</button>
                       <button 
                         onClick={() => setSoundMode('all')}
                         className={`px-2 py-1 rounded ${soundMode === 'all' ? 'bg-cyan-600 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                         title="High Fidelity: All Signals + Background Hum"
                       >All Signals</button>
                    </div>
                 </div>
                 <div className="flex items-center justify-between gap-4">
                    <span className="text-zinc-400">Tone:</span>
                     <div className="flex bg-zinc-800 rounded p-0.5">
                       <button 
                         onClick={() => setSoundTheme('mechanical')}
                         className={`px-2 py-1 rounded ${soundTheme === 'mechanical' ? 'bg-amber-600 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                       >Mech</button>
                       <button 
                         onClick={() => setSoundTheme('modern')}
                         className={`px-2 py-1 rounded ${soundTheme === 'modern' ? 'bg-amber-600 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                       >Modern</button>
                    </div>
                 </div>
               </div>
             )}
             
             <button
               onClick={() => setShowSoundSettings(!showSoundSettings)}
               className="p-3 rounded-full shadow-lg bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors"
               title="Audio Settings"
             >
               <Settings size={20} />
             </button>

             <button 
               onClick={toggleMute}
               className={`p-3 rounded-full shadow-lg transition-all ${isMuted ? 'bg-zinc-800 text-zinc-400' : 'bg-emerald-500 text-white hover:bg-emerald-600'}`}
               title={isMuted ? "Unmute MRI Sound" : "Mute MRI Sound"}
             >
               {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
             </button>
           </div>
        </div>

        {/* Equation Header */}
        <EquationViewer seqParams={seqParams} />

        <div className="flex-1 p-4 lg:p-6 overflow-y-auto">
          <div className="flex gap-4 mb-4 border-b border-zinc-800">
             <button 
               onClick={() => setActiveView('vector')}
               className={`pb-2 text-sm font-medium transition-colors flex items-center gap-2 ${activeView === 'vector' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-zinc-500 hover:text-zinc-300'}`}
             >
                <Activity size={16} /> Vector Physics
             </button>
             <button 
               onClick={() => setActiveView('kspace')}
               className={`pb-2 text-sm font-medium transition-colors flex items-center gap-2 ${activeView === 'kspace' ? 'text-purple-400 border-b-2 border-purple-400' : 'text-zinc-500 hover:text-zinc-300'}`}
             >
                <Grid size={16} /> K-Space & Encoding
             </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 h-full min-h-[500px]">
            
            <div className="flex flex-col gap-4 h-[400px] lg:h-full">
               {activeView === 'vector' ? (
                 <>
                    <VectorView 
                      seqParams={seqParams} 
                      tissueParams={tissueParams}
                      timeInTR={timeInTR}
                    />
                    <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4 flex items-center justify-between">
                        <div>
                        <h4 className="text-zinc-400 text-xs uppercase tracking-wider">Signal Intensity</h4>
                        <p className="text-zinc-500 text-[10px]">Steady State Amplitude</p>
                        </div>
                        <div className="flex items-baseline gap-2">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: tissueParams.color }}></div>
                            <div className="text-3xl font-bold font-mono text-white">
                                {(signal * Math.min(seqParams.gxAmp, 1)).toFixed(3)}
                            </div>
                        </div>
                    </div>
                 </>
               ) : (
                 <KSpaceView 
                    seqParams={seqParams} 
                    timeInTR={timeInTR}
                    kSpaceLine={kSpaceLine}
                    setKSpaceLine={setKSpaceLine}
                    isAcquiring={isAcquiring}
                    setIsAcquiring={setIsAcquiring}
                 />
               )}
            </div>

            <div className="h-[300px] lg:h-full">
              <Charts 
                seqParams={seqParams}
                tissueParams={tissueParams}
                ernstAngle={ernstAngle}
              />
            </div>

            <div className="col-span-1 lg:col-span-2 mt-auto pt-4 text-center lg:text-left">
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 text-xs text-blue-200 flex items-center gap-2">
                <span className="text-xl">ℹ️</span>
                <div>
                  {activeView === 'vector' 
                    ? <strong>Audio Simulation:</strong> 
                    : <strong>Phase & Frequency Encoding:</strong>
                  }
                  {activeView === 'vector' 
                     ? ` The sound is currently in ${soundMode === 'visual' ? 'Visual Sync' : (soundMode === 'all' ? 'High Fidelity' : 'Real-Time Physics')} mode. ${soundMode === 'all' ? 'All signals (gradients + background) are audible.' : (soundMode === 'visual' ? 'It matches the animation speed for education.' : 'It matches the true millisecond timing.')}`
                     : " Use the Phase Controller controls to auto-play or manually scrub through K-Space lines. Note how the Phase Gradient pitch changes with amplitude (louder at edges)."
                  }
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default App;